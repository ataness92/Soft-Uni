from unittest import TestCase, main

from project.social_media import SocialMedia


class TestSocialMedia(TestCase):

    def setUp(self) -> None:
        self.social_media = SocialMedia('atanas', 'Instagram', 10, 'football')

    def test_correct_init(self):
        self.assertEqual('atanas', self.social_media._username)
        self.assertEqual('Instagram', self.social_media.platform)
        self.assertEqual(10, self.social_media._followers)
        self.assertEqual('football', self.social_media._content_type)
        self.assertEqual([], self.social_media._posts)


    def test_incorrect_init_for_incorrect_platform(self):
        pass