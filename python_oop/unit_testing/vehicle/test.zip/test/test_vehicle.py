from unittest import TestCase, main
from project.vehicle import Vehicle

class TestVehicle(TestCase):

    def setUp(self) -> None:
        self.vehicle = Vehicle(0.2, 1.5)

    def test_init(self):
        self.assertEqual(0.2, self.vehicle.fuel)
        self.assertEqual(0.2, self.vehicle.capacity)
        self.assertEqual(1.5, self.vehicle.horse_power)
        self.assertEqual(1.25, self.vehicle.DEFAULT_FUEL_CONSUMPTION)