from unittest import TestCase, main
from project.student import Student

class TestStudent(TestCase):

    def setUp(self) -> None:
        self.student = Student("Atanas")
        #self.second_student = Student("Plamena", ['python'])

    def test_correct_init(self):
        self.assertEqual("Atanas", self.student.name)
        self.assertEqual({}, self.student.courses)