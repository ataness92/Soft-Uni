from unittest import TestCase, main

from project.hero import Hero


class TestHero(TestCase):

    def setUp(self) -> None:
        self.hero = Hero("Atanas", 99, 10000.1, 100000.5)

    def test_init(self):
        self.assertEqual("Atanas", self.hero.username)
        self.assertEqual(99, self.hero.level)
        self.assertEqual(10000.1, self.hero.health)
        self.assertEqual(100000.5, self.hero.damage)



if __name__ == '__main__':
    main()